public class Knoten 
{
	public boolean istBesucht= false;  	//Variable, ob Ort besucht ist
	String schluessel;
	
	public Knoten(String schluessel) 
	{
		this.schluessel= schluessel;
	}

	String schluesselGeben() 
	{
		return schluessel;
	}
}
