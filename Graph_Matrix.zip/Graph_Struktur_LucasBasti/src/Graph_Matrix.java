
public class Graph_Matrix {
	int[][] matrix;
	int maxAnz;
	Knoten []  knoten;
	
	//Konstruktor
	
	public Graph_Matrix(int maxAnz) {
		this.maxAnz=maxAnz;
		matrix = new int[maxAnz][maxAnz];
	    knoten = new Knoten [maxAnz];
		for(int i=0; i<maxAnz; i++) {
			for(int j=0; j<maxAnz; j++) {
				matrix[j][i]=-1;
			}
		}
		
	}
	
	
	
	public int anzahlKnoten() {
		int n= 0;
		while(knoten[n]!=null && n < maxAnz) {
			n++;		
		}
		return n+1;
	}
	
	
	public void ausgeben() {
		System.out.print("\t");
		for(int y=0;y<maxAnz; y++) {
			if(y< anzahlKnoten()-1) {
				System.out.print(knoten[y].schluesselGeben().substring(0, 1)+"\t");
			}	
		}
		System.out.println();
		for(int y=0;y<anzahlKnoten()-1; y++) {
			
			if(y< anzahlKnoten()-1) {
				System.out.print(knoten[y].schluesselGeben().substring(0, 1));
			}
			System.out.print("\t");
			for(int x=0; x<anzahlKnoten()-1; x++) {
				
				System.out.print(matrix[x][y]+"\t");
				
			}
			System.out.println();
		}
	}
	
	
	public void  knotenEinfuegen(Knoten kneu) {
				knoten [anzahlKnoten()-1]= kneu;
				matrix[anzahlKnoten()-2][anzahlKnoten()-2] = 0;			
	}

	
	public int knotenIndexGeben(String suchSchluessel) {		
		int n= 0;
		while(knoten[n]!=null && n < maxAnz && suchSchluessel != knoten[n].schluesselGeben()) {
			n++;
		}
		return n;
	}

	
	public void kanteEinfuegen(String vonKnoten, String nachKnoten, int gewichtung) {
		int von;
		int nach;
		von = knotenIndexGeben(vonKnoten);
		nach = knotenIndexGeben(nachKnoten);			
		matrix[nach][von]= gewichtung;
	}
	
	
	public void tiefenSuche(String knotenName)
	{
		int knotenIndex=knotenIndexGeben(knotenName);  // KnotenIndex und Knoten werden verbunden
		knoten[knotenIndex].istBesucht=true;
		System.out.println("erreicht "+ knoten[knotenIndex].schluesselGeben()); //Gibt erreichten Knoten aus
		
		for(int c=0; c<anzahlKnoten()-1;c++) 
		{
			if(matrix[c][knotenIndex]> 0 && knoten[c].istBesucht!=true)		//Wenn der Wert > 0 ist und unbesucht ist; Sobal kein unbesuchter mehr besucht werden kann sucht man im neuen lauf nach Alternativen
			{			
				tiefenSuche(knoten[c].schluesselGeben());							//rekursiv, da unbesucht gesucht wird
				System.out.println("zu Vorg�nger " +knoten[knotenIndex].schluesselGeben()+ " zur�ck"); //nachdem kein anderer Weg wurde => neue Alternative in fr�herer Station
				
			}
		}
	}
	
}
