
public class Programm 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Graph_Matrix g = new Graph_Matrix(10);
		g.knotenEinfuegen(new Knoten("Weller"));
		g.knotenEinfuegen(new Knoten("Altdorf"));
		g.knotenEinfuegen(new Knoten("Ziegelstein"));
		g.knotenEinfuegen(new Knoten("Fischbach"));
		g.knotenEinfuegen(new Knoten("Neustadt"));
		g.knotenEinfuegen(new Knoten("Burg"));
		g.knotenEinfuegen(new Knoten("Rain"));
		g.kanteEinfuegen("Altdorf","Weller",15 );
		g.kanteEinfuegen("Fischbach","Weller",10);
		g.kanteEinfuegen("Fischbach","Altdorf",10 );
		g.kanteEinfuegen("Weller","Ziegelstein",5 );
		g.kanteEinfuegen("Burg","Ziegelstein",5 );
		g.kanteEinfuegen("Weller","Fischbach",25 );
		g.kanteEinfuegen("Altdorf", "Fischbach", 20);
		g.kanteEinfuegen("Ziegelstein", "Fischbach", 15);
		g.kanteEinfuegen("Altdorf", "Fischbach", 20);
		g.kanteEinfuegen("Burg", "Fischbach", 15);
		g.kanteEinfuegen("Ziegelstein", "Neustadt", 15);
		g.kanteEinfuegen("Ziegelstein", "Burg", 20);
		g.kanteEinfuegen("Rain", "Burg", 25);
		g.kanteEinfuegen("Neustadt", "Rain", 20);
		g.ausgeben();
		
		System.out.println("Tiefensuche:");
		
		g.tiefenSuche("Burg");
		
		System.out.println("Die Tiefe des Knotens wurde erreicht");
	}
}
